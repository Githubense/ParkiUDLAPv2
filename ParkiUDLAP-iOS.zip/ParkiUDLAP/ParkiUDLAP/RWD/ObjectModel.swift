//
//  ObjectModel.swift
//  ParkiUDLAP
//
//  Created by iOS Lab on 11/04/24.
//

import Foundation

class ObjectModel: Encodable, Decodable, Hashable{
    var id: String = ""
    var value: String = ""
    
    // Hashable conformance
       static func == (lhs: ObjectModel, rhs: ObjectModel) -> Bool {
           return lhs.id == rhs.id && lhs.value == rhs.value
       }

       func hash(into hasher: inout Hasher) {
           hasher.combine(id)
           hasher.combine(value)
       }
}

extension Encodable{
    var toDictionary: [String: Any]?{
        guard let data = try? JSONEncoder().encode(self) else {
            return nil
        }
        
        return try? JSONSerialization.jsonObject(with: data, options: .allowFragments) as? [String: Any]
    }
}
