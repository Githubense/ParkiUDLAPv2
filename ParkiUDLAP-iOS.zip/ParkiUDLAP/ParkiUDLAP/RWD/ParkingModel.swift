//
//  ObjectModel.swift
//  ParkiUDLAP
//
//  Created by iOS Lab on 11/04/24.
//

import Foundation

class ParkingModel: Encodable, Decodable{
    var p1: String = ""
    var p2: String = ""
    var p3: String = ""
    var p4: String = ""
//
//    // Hashable conformance
//       static func == (lhs: ParkingModel, rhs: ParkingModel) -> Bool {
//           return lhs.p1 == rhs.p1 && lhs.p2 == rhs.p2 && lhs.p3 == rhs.p3 && lhs.p4 == rhs.p4
//       }
//
//       func hash(into hasher: inout Hasher) {
//           hasher.combine(p1)
//           hasher.combine(p2)
//           hasher.combine(p3)
//           hasher.combine(p4)
//
//       }
}

extension Encodable{
    var ParkingToDictionary: [String: Any]?{
        guard let data = try? JSONEncoder().encode(self) else {
            return nil
        }
        
        return try? JSONSerialization.jsonObject(with: data, options: .allowFragments) as? [String: Any]
    }
}

