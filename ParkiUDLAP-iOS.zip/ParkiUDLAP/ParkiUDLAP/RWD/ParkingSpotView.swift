//
//  ParkingSpotView.swift
//  ParkiUDLAP
//
//  Created by iOS Lab on 12/04/24.
//

import SwiftUI

struct ParkingSpotView: View {
    var park: Park
    @StateObject var viewModel = ParkingViewModel()
    @Environment(\.presentationMode) var mode: Binding<PresentationMode>

    var body: some View {
        NavigationStack {
            VStack {
                HStack {
                    Button {
                        self.mode.wrappedValue.dismiss()
                    } label: {
                        Image(systemName: "arrow.left")
                            .font(.system(size: 15, weight: .bold))
                            .padding(20)
                            .background(Color.gray.opacity(0.1))
                            .clipShape(Circle())
                    }
                    .foregroundColor(.black)
                    .padding(.leading, 13)

                    Text("\(park.name)")
                        .font(.system(size: 30))
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(.top, 5)

                // Define the grid layout
                let columns = [
                    GridItem(.flexible(), spacing: 16),
                    GridItem(.flexible(), spacing: 16)
                ]

                LazyVGrid(columns: columns, spacing: 16) {
                    ForEach(viewModel.parkingSpots.indices, id: \.self) { index in
                        if !viewModel.parkingSpots[index] {
                            Image("Car")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100, height: 50)
                        } else {
                            NavigationLink() {
                                ParkingSpotMapView()
                            }label:{
                                Image("NoCar")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 100, height: 50)
                            }
                        }
                    }
                }
            }
        }
        .onAppear {
            viewModel.readPark(parkName: park.address)
        }
        .navigationBarBackButtonHidden(true)
    }
}


struct BranchDetailCard: View{
    var park: Park
    var body: some View{
        ZStack{
                   ZStack{
                                   if(park.image == "angelopolis"){
                                       Image(park.image)
                                           .resizable()
                                           .padding(.bottom)
                                           .scaledToFit()
                                           .padding(.trailing)
                                           .padding(.leading,50)
                                           .scaleEffect(x:3,y:3)
                                   }
                                   
                                   else if(park.image == "sonata"){
                                       Image(park.image)
                                           .resizable()
                                           .padding(.top,40)
                                           .padding(.bottom)
                                           .scaledToFit()
                                           .padding(.trailing,5)
                                           .padding(.leading)
                                           .rotationEffect(Angle(degrees:0))
                                           .scaleEffect(x:3,y:3)
                                   }
                                   
                                   else if(park.image == "centro"){
                                       Image(park.image)
                                           .resizable()
                                           .padding(.top,60)
                                           .padding(.bottom)
                                           .scaledToFit()
                                           .padding(.trailing, 50)
                                           .padding(.leading)
                                           .rotationEffect(Angle(degrees:0))
                                           .scaleEffect(x:3,y:3)
                                   }
                                   
                                   else{
                                       Image(park.image)
                                           .resizable()
                                           .padding(.top)
                                           .padding(.bottom)
                                           .scaledToFit()
                                           .padding(.trailing)
                                           .padding(.leading)
                                           .rotationEffect(Angle(degrees:0))
                                           .scaleEffect(x:3,y:3)
                                   }
                                   
                                   VStack(alignment: .leading, content: {
                                       Text("\(park.name)")
                                           .font(.system(size: 36, weight: .semibold))
                                       
                                       
                                       StarView(numberOfStars: park.star)
                                                                   .padding()
                                                                   .background(.white.opacity(0.6))
                                                                   .clipShape(Capsule())
                                       
                                       Spacer()
                                       
                                       HStack{
                                           Text(verbatim: "Phone: \(park.number)")
                                               .font(.system(size: 18, weight: .semibold))
                                               .padding(.leading, 10)
                                           
                                           Spacer()
                                           
                                           Button{
                                               
                                           }label: {
                                               Image(systemName: "phone")
                                                   .imageScale(.large)
                                                   .frame(width:90, height: 68)
                                                   .background(.black)
                                                   .clipShape(Capsule())
                                                   .foregroundColor(.white)
                                               
                                           }
                                           
                                       }
                                       .padding(.leading)
                                       .padding()
                                       .frame(maxWidth: .infinity)
                                       .frame(height:100)
                                       .background(.white.opacity(0.9))
                                       .cornerRadius(40)
                                       
                                       HStack{
                                           VStack {
                                               Text("\(park.address)")
                                                   .font(.system(size: 15, weight: .semibold))
                                                   .padding(.bottom, 1)
                                               
                                               Text("\(park.description)")
                                                   .font(.system(size: 15))
                                           }
                                           
                                           Spacer()
                                           
                                           Button{
                                               
                                           }label: {
                                               Image(systemName: "location")
                                                   .imageScale(.large)
                                                   .frame(width:90, height: 68)
                                                   .background(.black)
                                                   .clipShape(Capsule())
                                                   .foregroundColor(.white)
                                               
                                           }
                                           
                                       }
                                       .padding(.leading)
                                       .padding()
                                       .frame(maxWidth: .infinity)
                                       .frame(height:200)
                                       .background(.white.opacity(0.9))
                                       .cornerRadius(40)
                                   })
                               }
                               .padding(30)
                               .frame(width:350, height: 600)
                           }
                           .frame(width: 350, height: 600)
                           .background(park.color.opacity(0.13))
                           .clipShape(.rect(cornerRadius: 57))
                           .padding()
    }
}

struct StarView: View {
    var numberOfStars: Int

    var body: some View {
        HStack {
            ForEach(0..<numberOfStars, id: \.self) { _ in
                Image(systemName: "star.fill")
                    .foregroundColor(.black) // Or any color you want
            }
        }
    }
}

struct ParkingSpotView_Previews: PreviewProvider {
    static var previews: some View {
        // Create a mock Branch object with a UUID for the id
        let mockPark =     Park(name: "Centro Historico", address: "Calle 10 Nte 603,\nSan Miguel, Barrio de San Miguel Tianguisnahuitl,\n72760\nSan Andrés Cholula", image:"centro", star:4, color: .green, description: "2PM to 7PM", number:9612394535)
        ParkingSpotView(park: mockPark)
    }
}
