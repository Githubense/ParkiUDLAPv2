//
//  Perfil.swift
//  ParkiUdlap
//
//  Created by iOS Lab on 28/04/24.
//

import SwiftUI

struct ProfileView: View {
    var body: some View {
        ZStack{
            Color(Color.udlapGreen)
                .edgesIgnoringSafeArea(.all)
            VStack{
                Text("Perfil")
                    .font(.title)
                    .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                    .padding(.trailing, 280)
                    .padding(.bottom, 10.0)
                    .foregroundColor(.white)
                    .padding(.top, 150)
                ZStack{
                    Circle()
                        .frame(width: 160,height: 160)
                        .foregroundColor(.white)
                        .offset(y:8)
                    Image("pimienta")
                        .resizable()
                        .frame(width: 150,height: 150)
                        .clipShape(Circle())
                        .aspectRatio(contentMode: .fill)
                        .padding(.top)
                }
                Text("Ángel Pimienta")
                    .font(.title)
                    .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                    .padding(.trailing, 0)
                    .foregroundColor(.white)
                Text("Chirey Tiggo 7 Pro")
                    .font(.title2)
                    .foregroundColor(.white)
                Text("Alumno")
                    .foregroundColor(.white)
                
               
                
                VStack{
                    HStack{
                        Image(systemName: "pencil.line")
                            .imageScale(.large)
                            .foregroundStyle(.black)
                        Text("Editar información")
                            .padding(.trailing, 150.0)
                    }
                    .padding(.top, 40)
                   
                    HStack{
                        Image(systemName: "gearshape.fill")
                            .imageScale(.large)
                            .foregroundStyle(.black)
                        Text("Ajustes")
                            .padding(.trailing, 230.0)
                            
                    }
                    .padding(.top, 10)
                    HStack{
                        Image(systemName: "questionmark.circle.fill")
                            .imageScale(.large)
                            .foregroundStyle(.black)
                        Text("Ayuda")
                            .padding(.trailing, 240.0)
                            
                       
                    }
                    .padding(.top, 10)
                    
                    Divider()
                    HStack{
                        Image(systemName: "plus")
                            .imageScale(.large)
                            .foregroundStyle(.black)
                        Text("Añadir auto")
                            .padding(.trailing, 210.0)
                            .padding(.bottom, 10.0)
                           
                        
                    }
                    .padding(.top, 10)
                    HStack{
                        Image(systemName: "plus")
                            .imageScale(.large)
                            .foregroundStyle(.black)
                        Text("Añadir método de pago")
                            .padding(.trailing, 120.0)
                    }
                    .padding(.top, 10)
                Spacer()
                    
                    
                }
                .frame(width: .infinity, height: 520)
                .background(Color(.white))
                .cornerRadius(20)
                .shadow(radius: 3)
                .padding(.bottom,10)
                
            }//VSTACK
            
        }//ZSTACK
    }
}

#Preview {
    ProfileView()
}
