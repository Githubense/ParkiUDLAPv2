//
//  WriteViewModel.swift
//  ParkiUDLAP
//
//  Created by iOS Lab on 11/04/24.
//

import SwiftUI
import Foundation
import FirebaseDatabase
import FirebaseDatabaseSwift

class WriteViewModel: ObservableObject{
    
    private let ref = Database.database().reference()
    
    private var number = 0
    private var string = "Demo value"
    
    func pushNewValue(value:Int){
        ref.child("Child 1").setValue(value)
    }
    
    func pushObject(){
        let generateObject = ObjectModel()
        generateObject.id = String(number)
        generateObject.value = String(string)
        
        ref.child(generateObject.id).setValue(generateObject.toDictionary)
        number+=1
    }
}
